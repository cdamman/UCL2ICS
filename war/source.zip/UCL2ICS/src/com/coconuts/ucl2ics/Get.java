/*
 * UCL2ICS v3 APP ENGINE EDITION
 * By Corentin Damman
 */

package com.coconuts.ucl2ics;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class Get extends HttpServlet {
	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {		
		String key = req.getParameter("key");
		PersistenceManager pm = PMF.get().getPersistenceManager();
		
		try {
			if (key == null) {
				resp.setContentType("text/html");
				resp.getWriter().println("Error<br>");
			} else if (key.isEmpty()) {
				resp.setContentType("text/html");
				resp.getWriter().println("Error<br>");
			} else {
				boolean verified = false;
				
				Query query = pm.newQuery(Student.class);
				query.setFilter("keyString == keyStringSearch");
				query.setOrdering("keyString desc");
				query.declareParameters("String keyStringSearch");
				
				try {
					List<Student> results = (List<Student>) query.execute(key);
					if (results.iterator().hasNext())
						for (Student e : results) {
							verified = true;
							resp.setContentType("text/calendar");
							resp.setCharacterEncoding("UTF-8");
							resp.setHeader("Content-Disposition", "inline; filename=ade.ics");
							try {
					            /*URL url = new URL("http://ucl2icsphp.appspot.com/ade.php?codes="+e.getCodes().getValue()+
									"&courses="+e.getCourses().getValue()+"&weeks="+e.getSemaines()+"&project="+e.getProjectID()+"&dh="+e.getSTFU());
					            URLConnection conn = url.openConnection();
					            conn.setReadTimeout(15000);
					            conn.setConnectTimeout(15000);
					            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					            String line;

					            while ((line = reader.readLine()) != null) {
					            	resp.getWriter().println(line);
					            }
					            reader.close();*/
								resp.sendRedirect("http://ucl2icsphp.appspot.com/ade.php?codes="+URLEncoder.encode(e.getCodes().getValue(), "UTF-8")+
									"&courses="+URLEncoder.encode(e.getCourses().getValue(), "UTF-8")+"&weeks="+e.getSemaines()+"&project="+e.getProjectID()+"&dh="+e.getSTFU());
					        } catch (IOException e2) {
								resp.setContentType("text/html");
								resp.getWriter().println("Error while getting agenda !<br>"+e2.getMessage());
					        } //*/
							/*resp.setContentType("text/html");
							resp.getWriter().println("http://localhost:8080/ade.php?codes="+URLEncoder.encode(e.getCodes().getValue(), "UTF-8")+
									"&courses="+URLEncoder.encode(e.getCourses().getValue(), "UTF-8")+"&weeks="+e.getSemaines()+"&project="+e.getProjectID()+"&dh="+e.getSTFU()); //*/
							e.addCount();
						}
				} finally {
					query.closeAll();
				}

				if (!verified) {
					resp.setContentType("text/html");
					resp.getWriter().println("404 Not found");
				}
			}
		} finally {
			pm.close();
		}
	}
}