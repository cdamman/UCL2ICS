/*
 * UCL2ICS v3 APP ENGINE EDITION
 * By Corentin Damman
 */

package com.coconuts.ucl2ics;

import java.io.IOException;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;

@SuppressWarnings("serial")
public class Admin extends HttpServlet {
	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		UserService userService = UserServiceFactory.getUserService();
		User user = userService.getCurrentUser();
		
		if (user != null) {
			if (PMF.checkAdministrator(user.getEmail())) {
				resp.setContentType("text/html");
				resp.getWriter().println("<html><head>" +
						"<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">" +
						"<title>Admin</title><style>td { width:80px; max-width:200px; } tr:nth-child(even) {background: #CCC} tr:nth-child(odd) {background: #FFF} </style>" +
						"</head><body><div style=\"float: left;\"><font size=\"6\" face=\"Comic Sans MS\">Admin</font></div><div style=\"float: right;\"><a href=\"" + 
						userService.createLogoutURL(req.getRequestURI()) + "\">Log Out</a></div>  <br><br><center><h4>Available Students:</h4></center>" + 
						"  <table border=\"1\" align=\"center\"><tr><th>&nbsp;Key (String)&nbsp;</th><th width=20%>&nbsp;Codes&nbsp;</th><th width=40%>&nbsp;Courses&nbsp;</th><th width=20%>&nbsp;Semaines&nbsp;</th><th>&nbsp;Projet&nbsp;</th><th>&nbsp;STFU&nbsp;</th><th>&nbsp;Count&nbsp;</th><th>&nbsp;Outils&nbsp;</th></tr>");
				
				PersistenceManager pm = PMF.get().getPersistenceManager();
				int number = 0;
				try {
					Query query = pm.newQuery(Student.class);
					//query.setOrdering("codes asc");
					
					try {
						List<Student> results = (List<Student>) query.execute();
						if (results.iterator().hasNext()) {
							for (Student e : results) {
								number++;
								resp.getWriter().println("    <tr>      " + e.getAll() + "    </tr>");
							}
						} else {
							resp.getWriter().println("    <tr>      <td>No clients</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>    </tr>");
						}
					} finally {
						query.closeAll();
					}
				} finally {
					resp.getWriter().println("  </table>  <center><h4>Number of Students: "+String.valueOf(number)+"</h4></center>    <br></body></html>");
					pm.close();
				}
			} else {
				resp.setContentType("text/html");
				resp.getWriter().println("<h1>Unauthorized</h1><a href=\"" + userService.createLogoutURL(req.getRequestURI()) + "\">Log Out</a>");
			}
		} else resp.sendRedirect(userService.createLoginURL(req.getRequestURI()));
	}
}