/*
 * UCL2ICS v3 APP ENGINE EDITION
 * By Corentin Damman
 */

package com.coconuts.ucl2ics;

import java.util.Calendar;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManagerFactory;

public final class PMF {
	private static final PersistenceManagerFactory pmfInstance = JDOHelper.getPersistenceManagerFactory("transactions-optional");
	
	public static PersistenceManagerFactory get() {
		return pmfInstance;
	}
	
	public static boolean checkAdministrator(String email) {
		if ((email.equals("cocod.tm@gmail.com")) || (email.equals("dev.coconuts@gmail.com") || (email.equals("guillaumederval@gmail.com"))))
			return true;
		else return false;
	}
	
	public static boolean isset(String str) {
		if (str == null)
			return false;
		else if (str.isEmpty())
			return false;
		else return true;
	}
	
	public static String header() {
		return 	"<html>" +
				"	<head>" +
				"		<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">" +
				"		<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"http://ucl2icsphp.appspot.com/favicon.ico\">" +
				"		<link rel=\"stylesheet\" href=\"http://ucl2icsphp.appspot.com/ade.css\">" +
				"		<title>UCL ADE to ICS</title>" +
				"	</head>" +
				"	<body>" +
				"		<h1>UCL ADE to ICS <span id=\"version\">v3.1 App Engine EDITION</span></h1>";
	}
	
	public static String footer() {
		return 	"		<div id=\"footer\">Par <a href=\"http://www.guillaumederval.be\" target=\"_blank\">Guillaume Derval</a>, r�-�crit sur Google App Engine par <a href=\"http://www.coconutsdev.tk\" target=\"_blank\">Corentin Damman</a>, bas� sur le code de Ploki<br>" +
				"		Voir le <a href=\"https://gist.github.com/GuillaumeDerval/6574088\" target=\"_blank\">code source PHP</a> ou le <a href=\"http://ucl2ics.appspot.com/source.zip\" target=\"_blank\">code source App Engine</a> ! Utiliser <a href=\"http://ucl2ics.appspot.com/API.pdf\" target=\"_blank\">l'API</a></div>" +
				"	</body>" +
				"</html>";
	}
	
	public static String beginForm(String codes, String semaines, int projectID) {
		return 	"<form class=\"top\" id=\"formulaire\" method=\"post\" action=\"http://ucl2icsphp.appspot.com/ade.php\">" +
				"<center><p><label for=\"codes\"><b>Codes cours</b> (s�par�s par virgules) ou <b>lien ADE</b> donn� par <a href=\"https://www.uclouvain.be/horaires-epl.html\" target=\"_blank\">l'outil horaire de l'EPL</a>: </label><br/>" +
				"<input type=\"text\" name=\"codes\" id=\"codes\" size=\"130\" value=\"" + codes + "\"/></p>" + 
				"<p><label for=\"semaines\"><b>Semaines</b> d�sir�es (s�par�es par virgules): </label><br/>" + 
				"<input type=\"text\" name=\"semaines\" id=\"semaines\" value=\"" + semaines + "\" size=\"130\"/><br/>" + 
				"<input type=\"button\" value=\"S�lectionner le 1er quadrimestre\" onClick=\"this.form.semaines.value='0,1,2,3,4,5,6,7,8,9,10,11,12,13'\">" + 
				"<input type=\"button\" value=\"S�lectionner le 2�me quadrimestre\" onClick=\"this.form.semaines.value='19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34'\">" + 
				"<input type=\"button\" value=\"S�lectionner cette semaine\" onClick=\"this.form.semaines.value='"+String.valueOf((Calendar.getInstance().get(3) + 14) % 51)+"'\">" + 
				"<input type=\"button\" value=\"S�lectionner toutes les semaines\" onClick=\"this.form.semaines.value='0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51'\"><br/>" + 
				"Nous sommes en S" + String.valueOf((Calendar.getInstance().get(3) + 14) % 51) + ". La premi�re semaine du premier quadrimestre est la semaine 0, et celle du second quadrimestre est la semaine 19</p>" +
				"<p><label for=\"projet\"><b>ID</b> du projet (pour 2013-2014, c'est 16): </label>" + 
				"<input type=\"text\" name=\"projet\" id=\"projet\" value=\"" + String.valueOf(projectID) + "\"/></p>" + 
				"<p><input type=\"checkbox\" name=\"deshurler\" id=\"deshurler\" checked=\"checked\"/><label for=\"deshurler\"><b>d�-HURLER</b> le nom des cours</label></p>" + 
				"<input type=\"submit\" value=\"Lancer\" /></center>" + 
				"</form>";
	}
	
	public static String splitVirgule(String longTexte) {
		String[] splitted = longTexte.split(",");
		String longTextSplitted = "";
		for(String dText : splitted) {
			longTextSplitted += ", "+dText;
		}
		return longTextSplitted.substring(2);
	}
}