/*
 * UCL2ICS v3 APP ENGINE EDITION
 * By Corentin Damman
 */

package com.coconuts.ucl2ics;

import java.io.IOException;

import javax.jdo.PersistenceManager;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.Text;

@SuppressWarnings("serial")
public class Set extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		doGet(req, resp);
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.setContentType("text/plain");
		
		Text codes = new Text(req.getParameter("codes"));
		Text courses = new Text(req.getParameter("courses"));
		String semaines = req.getParameter("weeks");
		String projectIDString = req.getParameter("project");
		String STFUString = req.getParameter("dh");
		
		PersistenceManager pm = PMF.get().getPersistenceManager();
		try {
			if ((codes == null) || (courses == null) || (semaines == null) || (projectIDString == null)) {
				resp.getWriter().println("Error");
			} else if ((codes.toString().isEmpty()) || (courses.toString().isEmpty()) || (semaines.isEmpty()) || (projectIDString.isEmpty())) {
				resp.getWriter().println("Error");
			} else {
				Student e = new Student(codes, courses, semaines, Integer.valueOf(projectIDString), BoolValueOf(STFUString));
				pm.makePersistent(e);
				e.setKeyString();
				resp.getWriter().println(e.getKeyString());
			}
		} finally {
			pm.close();
		}
	}
	
	private int BoolValueOf(String booleanString) {
		if(booleanString == null)
			return 0;
		else if(booleanString.isEmpty())
			return 0;
		else if(booleanString.equals("1"))
			return 1;
		else
			return 0;
	}
}