/*
 * UCL2ICS v3 APP ENGINE EDITION
 * By Corentin Damman
 */

package com.coconuts.ucl2ics;
 
import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;
 
@PersistenceCapable
public class Student {
 
	@PrimaryKey
	@Persistent(valueStrategy=IdGeneratorStrategy.IDENTITY)
	private Key key;
	 
	@Persistent
	private String keyString;
	 
	@Persistent
	private Text codes;
	 
	@Persistent
	private Text courses;
	 
	@Persistent
	private String semaines;
	 
	@Persistent
	private int projectID;
	 
	@Persistent
	private int STFU;
	 
	@Persistent
	private int counter;
	 
	public Student(Text codes, Text courses, String semaines, int projectID, int STFU) {
		this.codes = codes;
		this.courses = courses;
		this.semaines = semaines;
		this.projectID = projectID;
		this.STFU = STFU;
		this.counter = 0;
	}
	 
	public Key getKey() {
	    return key;
	}
	
	public void setKeyString() {
		this.keyString = key.toString();
	}
	
	public String getKeyString() {
		return keyString;
	}
	 
	public void setCodes(Text codes) {
		this.codes = codes;
	}
 
	public Text getCodes() {
		return codes;
	}
	 
	public void setCourses(Text courses) {
		this.courses = courses;
	}

	public Text getCourses() {
		return courses;
	}
 
	public void setSemaines(String semaines) {
		this.semaines = semaines;
	}
 
	public String getSemaines() {
		return semaines;
	}
 
	public void setProjectID(int projectID) {
		this.projectID = projectID;
	}
 
	public int getProjectID() {
		return projectID;
	}
 
	public void setSTFU(int STFU) {
		this.STFU = STFU;
	}
 
	public int getSTFU() {
		return STFU;
	}
 
	public String getAll() {
		return 	"<td>&nbsp;" + keyString + "&nbsp;</td>" + 
				"<td><center>&nbsp;" + PMF.splitVirgule(codes.getValue()) + "&nbsp;</center></td>" + 
				"<td><center>&nbsp;" + PMF.splitVirgule(courses.getValue()) + "&nbsp;</center></td>" + 
				"<td><center>&nbsp;" + PMF.splitVirgule(semaines) + "&nbsp;</center></td>" + 
				"<td><center>&nbsp;" + String.valueOf(projectID) + "&nbsp;</center></td>" + 
				"<td><center>&nbsp;" + String.valueOf(STFU) + "&nbsp;</center></td>" + 
				"<td><center>&nbsp;" + String.valueOf(counter) + "&nbsp;</center></td>" + 
				"<td><center>&nbsp;<a href=\"get?key=" + keyString + "\" target=\"_blank\">Agenda</a>&nbsp;<br>" +
							"&nbsp;<a href=\"modif?key=" + keyString + "\">Modifier</a>&nbsp;<br>" +
							"&nbsp;<a href=\"del?key=" + keyString + "\">Supprimer</a>&nbsp;</center></td>";
	}
 
	public void addCount() {
		this.counter++;
	}
	
	public void setCounter(int counter) {
		this.counter = counter;
	}
	
	public int getCounter() {
		return counter;
	}
}