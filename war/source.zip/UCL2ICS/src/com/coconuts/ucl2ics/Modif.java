/*
 * UCL2ICS v3 APP ENGINE EDITION
 * By Corentin Damman
 */

package com.coconuts.ucl2ics;

import java.io.IOException;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.Text;
import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;

@SuppressWarnings("serial")
public class Modif extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		doGet(req, resp);
	}
	
	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");
		
		UserService userService = UserServiceFactory.getUserService();
		User user = userService.getCurrentUser();
		
		if (user != null) {
			if (PMF.checkAdministrator(user.getEmail())) {
				String key = req.getParameter("key");
				PersistenceManager pm = PMF.get().getPersistenceManager();
				
				try {
					if (key == null) {
						resp.getWriter().println("Error<br>");
					} else if (key.isEmpty()) {
						resp.getWriter().println("Error<br>");
					} else {
						String codes = req.getParameter("codes");
						String courses = req.getParameter("courses");
						String semaines = req.getParameter("semaines");
						String projectIDString = req.getParameter("projectID");
						String STFUString = req.getParameter("STFU");
						String counter = req.getParameter("counter");
						
						if ((courses == null) || (codes == null) || (semaines == null) || (projectIDString == null) || (STFUString == null) || (counter == null)) {
							Text codesOld = new Text("");
							Text coursesOld = new Text("");
							String semainesOld = "";
							String projectIDOld = "";
							String STFUOld = "";
							String counterOld = "";
							
							Query query = pm.newQuery(Student.class);
							query.setFilter("keyString == keyStringSearch");
							query.setOrdering("keyString desc");
							query.declareParameters("String keyStringSearch");
							
							try {
								List<Student> results = (List<Student>) query.execute(key);
								if (results.iterator().hasNext())
									for (Student e : results) {
										codesOld = e.getCodes();
										coursesOld = e.getCourses();
										semainesOld = e.getSemaines();
										projectIDOld = String.valueOf(e.getProjectID());
										STFUOld = String.valueOf(e.getSTFU());
										counterOld = String.valueOf(e.getCounter());
									} else resp.getWriter().println("No results<br>");
							} finally {
								query.closeAll();
							}
							
							String page = "<BR><FORM METHOD=POST><table border=\"1\" align=\"center\"><tr><th>&nbsp;Variable&nbsp;</th><th>&nbsp;Value&nbsp;</th></tr><TR><TD>&nbsp;keyString&nbsp;</TD><TD><INPUT type=hidden name=\"key\" value=\"" + 
							key + "\" size=40>&nbsp;" + key + "&nbsp;</TD></TR>" + 
							"<TR><TD>&nbsp;Codes&nbsp;</TD><TD><INPUT type=text name=\"codes\" value=\"" + codesOld.getValue() + "\" size=80></TD></TR>" + 
							"<TR><TD>&nbsp;Courses&nbsp;</TD><TD><textarea name=\"courses\" rows=\"15\" cols=\"75\">" + coursesOld.getValue() + "</textarea></TD></TR>" + 
							"<TR><TD>&nbsp;Semaines&nbsp;</TD><TD><INPUT type=text name=\"semaines\" value=\"" + semainesOld + "\" size=100></TD></TR>" + 
							"<TR><TD>&nbsp;ProjectID&nbsp;</TD><TD><INPUT type=text name=\"projectID\" value=\"" + projectIDOld + "\" size=40></TD></TR>" + 
							"<TR><TD>&nbsp;STFU ?&nbsp;</TD><TD><INPUT type=text name=\"STFU\" value=\"" + STFUOld + "\" size=40></TD></TR>" + 
							"<TR><TD>&nbsp;Counter&nbsp;</TD><TD><INPUT type=text name=\"counter\" value=\"" + counterOld + "\" size=40></TD></TR>" + 
							"<TR><TD COLSPAN=2><INPUT type=\"submit\" value=\"Envoyer\"></TD></TR>" + 
							"</TABLE></FORM>";
							resp.getWriter().println(page);
						} else if ((codes.isEmpty()) || (courses.isEmpty()) || (semaines.isEmpty()) || (projectIDString.isEmpty()) || (STFUString.isEmpty()) || (counter.isEmpty())) {
							resp.getWriter().println("Error<br>");
						} else {
							Query query2 = pm.newQuery(Student.class);
							query2.setFilter("keyString == keyStringSearch");
							query2.setOrdering("keyString desc");
							query2.declareParameters("String keyStringSearch");
							
							try {
								List<Student> results2 = (List<Student>) query2.execute(key);
								if (results2.iterator().hasNext())
									for (Student e2 : results2) {
										e2.setCodes(new Text(codes));
										e2.setCourses(new Text(courses));
										e2.setSemaines(semaines);
										e2.setProjectID(Integer.valueOf(projectIDString));
										e2.setSTFU(Integer.valueOf(STFUString));
										e2.setCounter(Integer.valueOf(counter));
										resp.getWriter().println("Modified<br><meta http-equiv=\"Refresh\" content=\"1;URL=admin\">");
									} else resp.getWriter().println("No results<br>");
							} catch (NumberFormatException e) {
								resp.getWriter().println("Error: " + e.getMessage() + "<br>");
							} finally {
								query2.closeAll();
							}
						}
					}
				} finally {
					resp.getWriter().println("<br><a href=\"admin\">Return</a>");
					pm.close();
				}
			} else {
				resp.getWriter().println("<h1>Unauthorized</h1>");
			}
		} else resp.sendRedirect(userService.createLoginURL(req.getRequestURI()));
	}
}